package prova.dbgps;

public class TryBug {
  // Clean Up will erase the following line
  @SuppressWarnings("unused")
  private boolean overwrite;

  public TryBug() {
    overwrite = false;
  }

}
